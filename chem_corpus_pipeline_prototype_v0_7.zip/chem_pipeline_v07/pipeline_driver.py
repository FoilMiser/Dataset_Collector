#!/usr/bin/env python3
"""
pipeline_driver.py (v0.7)

Reads:
  - targets.yaml (schema v0.7)
  - license_map.yaml

Produces:
  - queues/green_download.jsonl
  - queues/yellow_pipeline.jsonl
  - queues/red_rejected.jsonl
  - manifests/{target_id}/license_evidence.* + evaluation.json
  - queues/run_summary.json (human-readable dry-run report)

What it does (safe by default):
  - Fetches/snapshots license evidence URLs (HTML/PDF if served)
  - Normalizes license to SPDX-ish using license_map normalization rules
  - Scans for restriction phrases (no LLM / no TDM / no AI training)
  - Computes effective bucket based on profile + SPDX allow/conditional/deny + restriction phrase hits

It does NOT download giant dataset payloads; that's download_worker.py.

v0.6 changes:
  - Added dry-run summary report generation
  - Improved evidence snapshot with retry
  - Better error handling and logging

Not legal advice.
"""

from __future__ import annotations

import argparse
import dataclasses
import hashlib
import json
import re
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import yaml

try:
    import requests
except ImportError:
    requests = None


VERSION = "0.7"


def utc_now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

def ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)

def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def read_yaml(path: Path) -> Dict[str, Any]:
    return yaml.safe_load(path.read_text(encoding="utf-8"))

def write_jsonl(path: Path, rows: List[Dict[str, Any]]) -> None:
    ensure_dir(path.parent)
    with path.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")

def write_json(path: Path, obj: Dict[str, Any]) -> None:
    ensure_dir(path.parent)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

def normalize_whitespace(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "")).strip()

def lower(text: str) -> str:
    return (text or "").lower()

def contains_any(haystack: str, needles: List[str]) -> List[str]:
    hits = []
    h = lower(haystack)
    for n in needles:
        if n and lower(n) in h:
            hits.append(n)
    return hits


@dataclasses.dataclass
class LicenseMap:
    allow: List[str]
    conditional: List[str]
    deny_prefixes: List[str]
    normalization_rules: List[Dict[str, Any]]
    restriction_phrases: List[str]
    gating: Dict[str, str]
    profiles: Dict[str, Dict[str, Any]]

def load_license_map(path: Path) -> LicenseMap:
    m = read_yaml(path)
    spdx = m.get("spdx", {})
    normalization = m.get("normalization", {})
    restriction_scan = m.get("restriction_scan", {})
    gating = m.get("gating", {})
    profiles = m.get("profiles", {})

    return LicenseMap(
        allow=spdx.get("allow", []),
        conditional=spdx.get("conditional", []),
        deny_prefixes=spdx.get("deny_prefixes", []),
        normalization_rules=normalization.get("rules", []),
        restriction_phrases=restriction_scan.get("phrases", []),
        gating=gating,
        profiles=profiles,
    )


# ------------------------------
# Denylist (v0.7)
# ------------------------------

def load_denylist(path: Path) -> Dict[str, Any]:
    """Load denylist.yaml if present. Returns dict with keys: patterns (list)."""
    if not path or not path.exists():
        return {"patterns": []}
    try:
        d = read_yaml(path) or {}
        patterns = d.get("patterns", []) or []
        # Normalize expected fields
        norm = []
        for p in patterns:
            if not isinstance(p, dict):
                continue
            kind = str(p.get("type", "substring")).lower()
            value = str(p.get("value", "") or "")
            if not value:
                continue
            fields = p.get("fields", None)
            if fields is None:
                fields = ["id", "name", "license_evidence_url", "download_blob"]
            norm.append({
                "type": kind,
                "value": value,
                "fields": [str(f) for f in (fields or [])],
                "reason": str(p.get("reason", "") or "")
            })
        return {"patterns": norm}
    except Exception:
        return {"patterns": []}

def denylist_hits(denylist: Dict[str, Any], hay: Dict[str, str]) -> List[Dict[str, str]]:
    """Return list of matched denylist patterns with field + reason."""
    hits: List[Dict[str, str]] = []
    pats = (denylist or {}).get("patterns", []) or []
    for p in pats:
        kind = p.get("type", "substring")
        val = p.get("value", "")
        fields = p.get("fields", [])
        for f in fields:
            src = str(hay.get(f, "") or "")
            if not src:
                continue
            if kind == "regex":
                try:
                    if re.search(val, src, flags=re.IGNORECASE):
                        hits.append({"field": f, "pattern": val, "type": "regex", "reason": p.get("reason","")})
                        break
                except re.error:
                    continue
            else:
                if val.lower() in src.lower():
                    hits.append({"field": f, "pattern": val, "type": "substring", "reason": p.get("reason","")})
                    break
    return hits

# ------------------------------
# Manual review signoff (v0.7)
# ------------------------------

def read_review_signoff(manifest_dir: Path) -> Dict[str, Any]:
    """Read review_signoff.json if present."""
    p = manifest_dir / "review_signoff.json"
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}

def normalize_spdx(license_map: LicenseMap, evidence_text: str, spdx_hint: str) -> str:
    hint = normalize_whitespace(str(spdx_hint or ""))
    if hint and hint.upper() not in {"MIXED", "UNKNOWN", "DERIVED"}:
        return hint

    blob = normalize_whitespace(f"{hint} {evidence_text}")
    blob_l = lower(blob)

    for rule in license_map.normalization_rules:
        needles = [lower(x) for x in (rule.get("match_any") or []) if x]
        if any(n in blob_l for n in needles):
            return str(rule.get("spdx", "UNKNOWN")) or "UNKNOWN"

    if hint.upper() == "DERIVED":
        return "Derived"

    return "UNKNOWN"

def spdx_bucket(license_map: LicenseMap, spdx: str) -> str:
    s = str(spdx or "").strip()
    if not s or s.upper() == "UNKNOWN":
        return license_map.gating.get("unknown_spdx_bucket", "YELLOW")

    for pref in license_map.deny_prefixes:
        if s.startswith(pref):
            return license_map.gating.get("deny_spdx_bucket", "RED")

    if s in license_map.allow:
        return "GREEN"
    if s in license_map.conditional:
        return license_map.gating.get("conditional_spdx_bucket", "YELLOW")

    return license_map.gating.get("unknown_spdx_bucket", "YELLOW")


def fetch_url_with_retry(
    url: str,
    timeout_s: int = 30,
    max_retries: int = 3,
    backoff_base: float = 2.0
) -> Tuple[Optional[bytes], Optional[str], Dict[str, Any]]:
    """Fetch URL with retry and exponential backoff."""
    if requests is None:
        return None, "requests not installed; pip install requests", {"retries": 0}
    
    meta: Dict[str, Any] = {"retries": 0, "errors": []}
    
    for attempt in range(max_retries):
        try:
            r = requests.get(
                url,
                timeout=timeout_s,
                headers={"User-Agent": f"chem-corpus-pipeline/{VERSION}"}
            )
            r.raise_for_status()
            ctype = r.headers.get("Content-Type", "")
            meta["final_status"] = r.status_code
            return r.content, ctype, meta
        except Exception as e:
            meta["retries"] = attempt + 1
            meta["errors"].append({"attempt": attempt + 1, "error": repr(e)})
            if attempt < max_retries - 1:
                sleep_time = min(backoff_base ** attempt, 60)
                time.sleep(sleep_time)
    
    return None, f"Failed after {max_retries} attempts", meta

def snapshot_evidence(
    manifest_dir: Path,
    url: str,
    max_retries: int = 3
) -> Dict[str, Any]:
    result: Dict[str, Any] = {"url": url, "fetched_at_utc": utc_now(), "status": "skipped"}
    if not url:
        result["status"] = "no_url"
        return result

    content, info, meta = fetch_url_with_retry(url, max_retries=max_retries)
    result["fetch_meta"] = meta
    
    if content is None:
        result["status"] = "error"
        result["error"] = info
        return result

    ctype = info or ""
    digest = sha256_bytes(content)
    result.update({"status": "ok", "content_type": ctype, "sha256": digest, "bytes": len(content)})

    ext = ".html"
    if "pdf" in ctype.lower():
        ext = ".pdf"
    elif "json" in ctype.lower():
        ext = ".json"
    elif "text/plain" in ctype.lower():
        ext = ".txt"

    ensure_dir(manifest_dir)
    out_path = manifest_dir / f"license_evidence{ext}"
    out_path.write_bytes(content)
    result["saved_path"] = str(out_path)

    write_json(manifest_dir / "license_evidence_meta.json", result)
    return result

def extract_text_for_scanning(evidence: Dict[str, Any]) -> str:
    saved = str(evidence.get("saved_path") or "")
    if not saved:
        return ""
    p = Path(saved)
    if not p.exists():
        return ""
    if p.suffix.lower() in {".html", ".txt", ".json"}:
        try:
            return p.read_bytes().decode("utf-8", errors="ignore")
        except Exception:
            return ""
    return ""


def merge_gates(default_gates: List[str], gates_override: Dict[str, Any]) -> List[str]:
    if not gates_override:
        return list(default_gates)
    add = gates_override.get("add", []) or []
    remove = gates_override.get("remove", []) or []
    gates = [g for g in default_gates if g not in set(remove)]
    for g in add:
        if g not in gates:
            gates.append(g)
    return gates

def compute_effective_bucket(
    license_map: LicenseMap,
    license_profile: str,
    resolved_spdx: str,
    restriction_hits: List[str]
) -> str:
    profile = license_map.profiles.get(license_profile, {})
    default_bucket = str(profile.get("default_bucket", "YELLOW")).upper() or "YELLOW"

    if restriction_hits:
        return str(license_map.gating.get("restriction_phrase_bucket", "YELLOW")).upper()

    b = spdx_bucket(license_map, resolved_spdx).upper()
    order = {"GREEN": 0, "YELLOW": 1, "RED": 2}
    return max([default_bucket, b], key=lambda x: order.get(x, 1))


def generate_dry_run_report(
    targets: List[Dict[str, Any]],
    green_rows: List[Dict[str, Any]],
    yellow_rows: List[Dict[str, Any]],
    red_rows: List[Dict[str, Any]],
    queues_root: Path
) -> str:
    """Generate human-readable dry-run summary report."""
    lines = [
        "=" * 70,
        "CHEMISTRY CORPUS PIPELINE — DRY-RUN SUMMARY REPORT",
        f"Generated: {utc_now()}",
        f"Pipeline Version: {VERSION}",
        "=" * 70,
        "",
        "OVERVIEW",
        "-" * 40,
        f"  Total targets evaluated: {len(targets)}",
        f"  GREEN (ready to download): {len(green_rows)}",
        f"  YELLOW (needs review/transform): {len(yellow_rows)}",
        f"  RED (rejected): {len(red_rows)}",
        "",
    ]
    
    if green_rows:
        lines.extend([
            "GREEN TARGETS (will be downloaded)",
            "-" * 40,
        ])
        for r in green_rows[:20]:
            lines.append(f"  ✓ {r['id']}: {r['name'][:50]}")
            lines.append(f"      License: {r['resolved_spdx']}")
        if len(green_rows) > 20:
            lines.append(f"  ... and {len(green_rows) - 20} more")
        lines.append("")
    
    if yellow_rows:
        lines.extend([
            "YELLOW TARGETS (need additional processing)",
            "-" * 40,
        ])
        for r in yellow_rows[:20]:
            reason = "record-level filtering" if r.get("license_profile") == "record_level" else "manual review"
            if r.get("restriction_hits"):
                reason = f"restriction phrase: {r['restriction_hits'][0]}"
            lines.append(f"  ⚠ {r['id']}: {r['name'][:50]}")
            lines.append(f"      Reason: {reason}")
        if len(yellow_rows) > 20:
            lines.append(f"  ... and {len(yellow_rows) - 20} more")
        lines.append("")
    
    if red_rows:
        lines.extend([
            "RED TARGETS (rejected)",
            "-" * 40,
        ])
        for r in red_rows[:10]:
            lines.append(f"  ✗ {r['id']}: {r['name'][:50]}")
            lines.append(f"      License: {r['resolved_spdx']}")
        if len(red_rows) > 10:
            lines.append(f"  ... and {len(red_rows) - 10} more")
        lines.append("")
    
    lines.extend([
        "NEXT STEPS",
        "-" * 40,
        "  1. Review this summary for any unexpected classifications",
        "  2. Run download_worker.py with --execute to download GREEN targets",
        "  3. Run yellow_scrubber.py for YELLOW targets requiring transforms",
        "",
        "=" * 70,
    ])
    
    report = "\n".join(lines)
    
    # Write report to file
    report_path = queues_root / "dry_run_report.txt"
    report_path.write_text(report, encoding="utf-8")
    
    return report


def main() -> None:
    ap = argparse.ArgumentParser(description=f"Pipeline Driver v{VERSION}")
    ap.add_argument("--targets", required=True, help="Path to targets.yaml (v0.7)")
    ap.add_argument("--license-map", default=None, help="Path to license_map.yaml (defaults to companion_files.license_map)")
    ap.add_argument("--out-manifests", default=None, help="Override manifests_root")
    ap.add_argument("--out-queues", default=None, help="Override queues_root")
    ap.add_argument("--no-fetch", action="store_true", help="Do not fetch evidence URLs (offline mode)")
    ap.add_argument("--max-retries", type=int, default=3, help="Max retries for evidence fetching")
    ap.add_argument("--quiet", action="store_true", help="Suppress dry-run report output")
    args = ap.parse_args()

    targets_path = Path(args.targets).resolve()
    targets_cfg = read_yaml(targets_path)

    companion = targets_cfg.get("companion_files", {}) or {}
    license_map_path = Path(args.license_map or companion.get("license_map", "./license_map.yaml")).resolve()
    license_map = load_license_map(license_map_path)

    denylist_path = Path(companion.get("denylist", "./denylist.yaml")).resolve()
    denylist = load_denylist(denylist_path)


    globals_cfg = targets_cfg.get("globals", {}) or {}
    manifests_root = Path(args.out_manifests or globals_cfg.get("manifests_root", "./manifests")).resolve()
    queues_root = Path(args.out_queues or globals_cfg.get("queues_root", "./queues")).resolve()
    ensure_dir(manifests_root)
    ensure_dir(queues_root)

    default_gates = globals_cfg.get("default_gates", []) or []
    targets = targets_cfg.get("targets", []) or []

    green_rows: List[Dict[str, Any]] = []
    yellow_rows: List[Dict[str, Any]] = []
    red_rows: List[Dict[str, Any]] = []

    for t in targets:
        enabled = bool(t.get("enabled", True))
        tid = str(t.get("id", "")).strip() or "unknown_id"
        name = str(t.get("name", tid))
        profile = str(t.get("license_profile", "unknown"))
        evidence = t.get("license_evidence", {}) or {}
        spdx_hint = str(evidence.get("spdx_hint", "UNKNOWN"))
        evidence_url = str(evidence.get("url", ""))

        # Flatten download config into a searchable blob for denylist scanning
        download_cfg = t.get("download", {}) or {}
        download_blob = json.dumps(download_cfg, ensure_ascii=False)
        review_required = bool(t.get("review_required", False))

        gates = merge_gates(default_gates, t.get("gates_override", {}) or {})

        target_manifest_dir = manifests_root / tid
        ensure_dir(target_manifest_dir)

        signoff = read_review_signoff(target_manifest_dir)
        review_status = str(signoff.get("status", "") or "").lower()  # approved | rejected | deferred
        promote_to = str(signoff.get("promote_to", "") or "").upper()
        dl_hay = {
            "id": tid,
            "name": name,
            "license_evidence_url": evidence_url,

            "review_required": review_required,
            "review_status": review_status or "pending",
            "denylist_hits": dl_hits,
            "download_blob": download_blob,
        }
        dl_hits = denylist_hits(denylist, dl_hay)

        evidence_snapshot = {"status": "skipped", "url": evidence_url}
        evidence_text = ""

        if "snapshot_terms" in gates and not args.no_fetch:
            evidence_snapshot = snapshot_evidence(
                target_manifest_dir,
                evidence_url,
                max_retries=args.max_retries
            )
            evidence_text = extract_text_for_scanning(evidence_snapshot)

        resolved = normalize_spdx(license_map, evidence_text=evidence_text, spdx_hint=spdx_hint)

        restriction_hits: List[str] = []
        if "restriction_phrase_scan" in gates:
            scan_blob = normalize_whitespace(f"{evidence_text} {evidence_url} {name}")
            restriction_hits = contains_any(scan_blob, license_map.restriction_phrases)

        eff_bucket = compute_effective_bucket(
            license_map=license_map,
            license_profile=profile,
            resolved_spdx=resolved,
            restriction_hits=restriction_hits,
        )

        # Denylist forces RED before any other gating
        if dl_hits:
            eff_bucket = "RED"

        # Manual review gating:
        # - If explicitly rejected: force RED
        # - If review_required and not approved: at least YELLOW (unless already RED)
        # - If approved with promote_to=GREEN: allow promotion to GREEN (conservative: only if no restriction hits)
        if review_status == "rejected":
            eff_bucket = "RED"
        elif review_required and eff_bucket != "RED" and review_status != "approved":
            if eff_bucket == "GREEN":
                eff_bucket = "YELLOW"
        elif review_status == "approved" and promote_to == "GREEN" and not restriction_hits and eff_bucket != "RED":
            eff_bucket = "GREEN"

        evaluation = {
            "id": tid,
            "name": name,
            "enabled": enabled,
            "evaluated_at_utc": utc_now(),
            "pipeline_version": VERSION,

            "review_required": review_required,
            "review_signoff": signoff or None,
            "review_status": review_status or "pending",
            "denylist_hits": dl_hits,
            "license_profile": profile,
            "spdx_hint": spdx_hint,
            "resolved_spdx": resolved,
            "restriction_hits": restriction_hits,
            "gates": gates,
            "effective_bucket": eff_bucket,
            "license_evidence_url": evidence_url,
            "evidence_snapshot": evidence_snapshot,
            "download": t.get("download", {}),
            "build": t.get("build", {}),
            "data_type": t.get("data_type", []),
            "priority": t.get("priority", None),
            "statistics": t.get("statistics", {}),
        }
        write_json(target_manifest_dir / "evaluation.json", evaluation)

        row = {
            "id": tid,
            "name": name,
            "effective_bucket": eff_bucket,
            "license_profile": profile,
            "resolved_spdx": resolved,
            "restriction_hits": restriction_hits,
            "license_evidence_url": evidence_url,
            "manifest_dir": str(target_manifest_dir),
            "download": t.get("download", {}),
            "build": t.get("build", {}),
            "data_type": t.get("data_type", []),
            "priority": t.get("priority", None),
            "enabled": enabled,
            "statistics": t.get("statistics", {}),
        }

        if not enabled:
            continue

        if eff_bucket == "GREEN":
            green_rows.append(row)
        elif eff_bucket == "YELLOW":
            yellow_rows.append(row)
        else:
            red_rows.append(row)

    def sort_key(r: Dict[str, Any]) -> Tuple[int, str]:
        p = r.get("priority", None)
        try:
            pi = int(p) if p is not None else -999999
        except Exception:
            pi = -999999
        return (-pi, str(r.get("id", "")))

    green_rows.sort(key=sort_key)
    yellow_rows.sort(key=sort_key)
    red_rows.sort(key=sort_key)

    write_jsonl(queues_root / "green_download.jsonl", green_rows)
    write_jsonl(queues_root / "yellow_pipeline.jsonl", yellow_rows)
    write_jsonl(queues_root / "red_rejected.jsonl", red_rows)

    summary = {
        "run_at_utc": utc_now(),
        "pipeline_version": VERSION,
        "targets_total": len(targets),
        "queued_green": len(green_rows),
        "queued_yellow": len(yellow_rows),
        "queued_red": len(red_rows),
        "targets_path": str(targets_path),
        "license_map_path": str(license_map_path),
        "manifests_root": str(manifests_root),
        "queues_root": str(queues_root),
    }
    write_json(queues_root / "run_summary.json", summary)
    
    # Generate and optionally print dry-run report
    report = generate_dry_run_report(targets, green_rows, yellow_rows, red_rows, queues_root)
    if not args.quiet:
        print(report)
    
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
