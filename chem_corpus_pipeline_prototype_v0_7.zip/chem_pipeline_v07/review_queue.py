#!/usr/bin/env python3
"""
review_queue.py (v0.7)

Manual review helper for YELLOW targets.

This script is intentionally lightweight and conservative:
- It reads YELLOW queue JSONL (emitted by pipeline_driver.py)
- It shows a summary of pending items
- It can write a review_signoff.json into each target's manifest dir

Signoff file schema (v0.1):
{
  "target_id": "...",
  "status": "approved" | "rejected" | "deferred",
  "reviewer": "Name",
  "reason": "Why",
  "promote_to": "GREEN" | "" ,   # optional
  "reviewed_at_utc": "YYYY-MM-DDTHH:MM:SSZ"
}
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List


VERSION = "0.7"


def utc_now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def read_jsonl(path: Path) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    rows = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return rows


def write_json(path: Path, obj: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def load_existing_signoff(manifest_dir: Path) -> Dict[str, Any]:
    p = manifest_dir / "review_signoff.json"
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}


def cmd_list(args: argparse.Namespace) -> int:
    yellow_rows = read_jsonl(Path(args.queue))
    if not yellow_rows:
        print("No YELLOW items found.")
        return 0

    pending = []
    for r in yellow_rows:
        mdir = Path(r.get("manifest_dir", ""))
        signoff = load_existing_signoff(mdir) if mdir else {}
        status = str(signoff.get("status", "") or "").lower()
        if status not in {"approved", "rejected"}:
            pending.append((r, status or "pending"))

    if not pending:
        print("No pending YELLOW items (all have signoffs).")
        return 0

    print("=" * 78)
    print(f"YELLOW REVIEW QUEUE (pending) — v{VERSION} — {utc_now()}")
    print("=" * 78)
    for r, status in pending[: args.limit]:
        print(f"- {r.get('id')}  [{status}]")
        print(f"  name: {r.get('name')}")
        print(f"  license_profile: {r.get('license_profile')}  resolved_spdx: {r.get('resolved_spdx')}")
        rh = r.get("restriction_hits") or []
        if rh:
            print(f"  restriction_hits: {rh[:3]}")
        dl = r.get("denylist_hits") or []
        if dl:
            print(f"  denylist_hits: {dl[:2]}")
        print(f"  license_evidence_url: {r.get('license_evidence_url')}")
        print(f"  manifest_dir: {r.get('manifest_dir')}")
        print()
    if len(pending) > args.limit:
        print(f"... and {len(pending) - args.limit} more")
    return 0


def write_signoff(target_id: str, manifest_dir: Path, status: str, reviewer: str, reason: str, promote_to: str = "") -> None:
    signoff = {
        "target_id": target_id,
        "status": status,
        "reviewer": reviewer,
        "reason": reason,
        "promote_to": promote_to,
        "reviewed_at_utc": utc_now(),
        "tool_version": VERSION,
    }
    write_json(manifest_dir / "review_signoff.json", signoff)


def find_target_in_queue(queue_path: Path, target_id: str) -> Dict[str, Any]:
    for r in read_jsonl(queue_path):
        if str(r.get("id", "")).strip() == target_id:
            return r
    return {}


def cmd_set(args: argparse.Namespace, status: str) -> int:
    qpath = Path(args.queue)
    row = find_target_in_queue(qpath, args.target)
    if not row:
        print(f"Target not found in queue: {args.target}")
        return 2

    mdir = Path(row.get("manifest_dir", ""))
    if not mdir.exists():
        print(f"Manifest dir does not exist: {mdir}")
        return 2

    promote_to = ""
    if status == "approved" and args.promote_to:
        promote_to = str(args.promote_to).upper()

    write_signoff(
        target_id=args.target,
        manifest_dir=mdir,
        status=status,
        reviewer=args.reviewer,
        reason=args.reason,
        promote_to=promote_to,
    )
    print(f"Wrote signoff: {mdir / 'review_signoff.json'}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(description="Manual review helper for YELLOW targets (v0.7).")
    ap.add_argument("--queue", default="/data/chem/_queues/yellow_pipeline.jsonl", help="Path to yellow queue JSONL")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p_list = sub.add_parser("list", help="List pending YELLOW items")
    p_list.add_argument("--limit", type=int, default=50)

    p_app = sub.add_parser("approve", help="Approve a YELLOW item (writes review_signoff.json)")
    p_app.add_argument("--target", required=True)
    p_app.add_argument("--reviewer", required=True)
    p_app.add_argument("--reason", required=True)
    p_app.add_argument("--promote-to", dest="promote_to", default="", help="Optional: set promote_to=GREEN")

    p_rej = sub.add_parser("reject", help="Reject a YELLOW item (forces RED in next classify pass)")
    p_rej.add_argument("--target", required=True)
    p_rej.add_argument("--reviewer", required=True)
    p_rej.add_argument("--reason", required=True)

    p_def = sub.add_parser("defer", help="Defer a YELLOW item (marks as deferred)")
    p_def.add_argument("--target", required=True)
    p_def.add_argument("--reviewer", required=True)
    p_def.add_argument("--reason", required=True)

    return ap


def main() -> int:
    ap = build_parser()
    args = ap.parse_args()
    if args.cmd == "list":
        return cmd_list(args)
    if args.cmd == "approve":
        return cmd_set(args, "approved")
    if args.cmd == "reject":
        return cmd_set(args, "rejected")
    if args.cmd == "defer":
        return cmd_set(args, "deferred")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
