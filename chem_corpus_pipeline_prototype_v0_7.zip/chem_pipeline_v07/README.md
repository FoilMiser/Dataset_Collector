# Chemistry Corpus Pipeline Prototype (v0.7)

A safety-first **prototype** pipeline for building a chemistry-focused training corpus from open datasets and open-access literature, with strong emphasis on **license compliance, provenance tracking, and safe-by-default execution**.

This repo helps you:
- keep a single inventory (`targets.yaml`) of candidate sources,
- snapshot license/terms evidence into per-target manifests,
- classify each source into **GREEN / YELLOW / RED** queues,
- run **download** (GREEN) and **scrub/extract** (YELLOW) stages,
- and build a global catalog / training manifests.

> Not legal advice. This tool helps you *track* licenses and restrictions; you are responsible for compliance.

---

## What This Pipeline Does

```
┌─────────────────┐     ┌────────────────────┐     ┌────────────────────────┐
│  targets.yaml   │────▶│ pipeline_driver.py  │────▶│  Queue JSONLs           │
│  (inventory)    │     │ (classify + gate)   │     │  GREEN / YELLOW / RED   │
└─────────────────┘     └──────────┬─────────┘     └───────────┬────────────┘
                                   │                            │
                                   │                            ▼
                                   │                   ┌──────────────────────┐
                                   │                   │ red_rejected.jsonl    │
                                   │                   │ (do not process)      │
                                   │                   └──────────────────────┘
                                   │
                                   ▼
                         ┌──────────────────┐
                         │ review_queue.py   │   (NEW in v0.7)
                         │ (manual signoff)  │
                         └──────────┬───────┘
                                    │
                                    ▼
        ┌───────────────────────────────────────────────────────────────────────┐
        │                         DATA ACQUISITION + TRANSFORMS                 │
        └───────────────────────────────────────────────────────────────────────┘
                 │                                │
                 ▼                                ▼
        ┌──────────────────┐              ┌────────────────────┐
        │ download_worker.py│              │ yellow_scrubber.py  │
        │ (GREEN downloads) │              │ (YELLOW transforms) │
        └─────────┬────────┘              └──────────┬──────────┘
                  │                                   │
                  ▼                                   ▼
        ┌────────────────────┐              ┌──────────────────────┐
        │ pools/permissive   │              │ pools/permissive      │
        │ pools/copyleft     │              │ (post-filtered/derived)│
        │ pools/quarantine   │              └──────────────────────┘
        └────────────────────┘
                  │
                  ▼
        ┌────────────────────┐
        │ catalog_builder.py  │  → global_catalog.json + training manifests
        └────────────────────┘
```

### Buckets
- **GREEN**: clear, compatible licensing + no disallowed restrictions → can be downloaded as-is
- **YELLOW**: ambiguous licensing or “restricted” sources → requires **manual signoff** and/or a safe transform (computed-only extraction, record-level filtering, etc.)
- **RED**: explicitly incompatible licenses/restrictions/denylist match → rejected

---

## What’s New in v0.7

### 1) Explicit denylist support (NEW)
- `denylist.yaml` allows you to force certain sources to **RED** based on:
  - substring matches, or
  - regex matches
- The driver scans:
  - target `id` / `name`
  - `license_evidence.url`
  - the serialized `download:` config blob

Any match forces `effective_bucket=RED`, regardless of SPDX.

### 2) Manual review signoff workflow (NEW)
- `review_queue.py` reads `yellow_pipeline.jsonl` and writes a signoff file:
  - `_manifests/{target_id}/review_signoff.json`

Signoff statuses:
- `approved` → removes “review_required” gating; optionally allows `promote_to: GREEN`
- `rejected` → forces RED next classify pass
- `deferred` → keeps YELLOW (no promotion)

### 3) Wrapper script includes `review` stage
`run_pipeline.sh --stage review` lists pending YELLOW items (no edits performed).

---

## Quick Start

### Install
```bash
pip install -r requirements.txt
```

### Dry-run (recommended first)
Creates manifests + queues, but does not download or transform:
```bash
./run_pipeline.sh --targets targets.yaml
```

### Review pending YELLOW items
```bash
./run_pipeline.sh --targets targets.yaml --stage review
# or:
python3 review_queue.py --queue /data/chem/_queues/yellow_pipeline.jsonl list
```

### Approve/reject a target (writes review_signoff.json)
```bash
python3 review_queue.py --queue /data/chem/_queues/yellow_pipeline.jsonl approve   --target pmc_oa_fulltext --reviewer "Your Name" --reason "PMC OA allowlist; evidence ok"

python3 review_queue.py --queue /data/chem/_queues/yellow_pipeline.jsonl reject   --target wikipedia_en --reviewer "Your Name" --reason "Terms restrict ML training"
```

Optional promotion (conservative; explicit):
```bash
python3 review_queue.py --queue /data/chem/_queues/yellow_pipeline.jsonl approve   --target some_target --reviewer "Your Name" --reason "Compatible after review" --promote-to GREEN
```

### Execute downloads + transforms
```bash
./run_pipeline.sh --targets targets.yaml --execute
```

### Build catalog
```bash
python3 catalog_builder.py --targets targets.yaml --output /data/chem/_catalogs/global_catalog.json
```

---

## Repository Layout

- `pipeline_driver.py` — classifies targets (GREEN/YELLOW/RED), snapshots evidence, emits queues
- `review_queue.py` — manual YELLOW review/signoff helper (NEW)
- `download_worker.py` — downloads GREEN items into the appropriate pool
- `yellow_scrubber.py` — stage-2 transforms for YELLOW items (PubChem computed-only extraction, PMC OA allowlist planner)
- `pmc_worker.py` — downloads + chunks allowlisted PMC OA full text
- `catalog_builder.py` — builds a global catalog and training manifests

### Configuration
- `targets.yaml` — dataset inventory + download/transform settings (schema v0.7)
- `license_map.yaml` — SPDX normalization rules + gating policy
- `field_schemas.yaml` — versioned schemas for extracted/normalized records
- `denylist.yaml` — explicit denylist patterns (NEW)

---

## Output Structure (default)

```
/data/chem/
  pools/
    permissive/
    copyleft/
    quarantine/
  _staging/
  _queues/
    green_download.jsonl
    yellow_pipeline.jsonl
    red_rejected.jsonl
    run_summary.json
  _manifests/
    {target_id}/
      evaluation.json
      license_evidence.{html,pdf,txt}
      review_signoff.json          # NEW (optional)
  _catalogs/
    global_catalog.json
```

---

## Notes / Safety

- **RED items should never be included in training manifests**, even if you have local copies.
- Prefer **computed-only** and **record-level allowlisting** when possible.
- Always snapshot license/terms evidence before large downloads.
- Treat “conditional” / ambiguous licenses as YELLOW until reviewed.

---

## License

Pipeline code is provided as-is for research and development use.

**Data sources retain their own licenses** — this tool helps you track and respect them.
